#include "gameObject.h"
#include "game.h"

GameObject::GameObject(const Game & mygame)
	: game(mygame)
{

}