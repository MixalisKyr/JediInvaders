#pragma once

#define ASSET_PATH "assets\\"
#define WINDOW_WIDTH 1200
#define WINDOW_HEIGHT 600
#define CANVAS_WIDTH 1000
#define CANVAS_HEIGHT 500
#define PLAYER_WIDTH 550
#define END_OF_LINE 350
#define ENEMY_WIDTH 100
#define BAR_WIDTH 400
#define BAR_HEIGHT 300
#define BAR_END 40
#define BAR_START 940
#define BULLET_STRIKE 10 //110
#define ENEMY_BULLET_STRIKE 550 //390