#pragma once
#include <random>

float rand0to1();

struct Disk
{
	float cx, cy;
	float radius;
};

struct Pos
{
	float pos_enemy_y, pos_enemy_x;
	float pos_player_y, pos_player_x;
};



